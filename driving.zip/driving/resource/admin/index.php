<?php
if(@page()){
// <<< from here output <<<
?>
כאן יבוא תוכן הדף
<?php
// >>> end of output >>>
}
?>
<?php
// --- כותרת ברירת חדל, תיאור בתגי מטא ברירת מחדל ומילות מפתח ברירת מחדל ---
$system['site_title']='driving';
$system['site_description']='';
$system['site_keywords']='';

// --- עיצוב ---
$system['template']='template';

// --- כתובת האתר ---
$system['site_url']='http://localhost/driving/';

// --- פרטי התחברות למסד נתונים ---
$system['db_host']='localhost';
$system['db_user']='root';
$system['db_pass']='';
$system['db_name']='';

// --- שם משתמש וסיסמה לאדמין האתר ---
$system['admin_username']='1';
$system['admin_password']='1';
$system['admin_email']='admin@gmail.com';


// --- הגדרת URL לדפים ---
$system['pages_dir']=array(
'דף ראשי'=>'index',
'אודות'=>'about',
'ניהול'=>'admin'
)
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="he" lang="he" dir="rtl">
<head>
	<link rel='stylesheet' href='<?=$system['site_url']?>style.css' type='text/css' media='screen'/>
	<title><?=$system['site_title']?></title>
    <meta name="description" content="<?=$system['site_description']?>" />
    <meta name="keywords" content="<?=$system['site_keywords']?>" />
	<meta http-equiv="content-Type" content="text/html; charset=utf-8" />
</head>
<body>


<?php
include("resource/".$system['page'].".php");
?>


</body>
</html>